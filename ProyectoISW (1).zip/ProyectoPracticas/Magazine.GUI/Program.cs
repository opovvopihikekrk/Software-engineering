﻿using Magazine.Persistence;
using Magazine.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Magazine.GUI
{
    internal static class Program
    {
        /// <summary>
        /// Punto de entrada principal para la aplicación.
        /// </summary>
        [STAThread]
        static void Main()
        {
            IMagazineService service = new MagazineService(new EntityFrameworkDAL(new MagazineDbContext()));
            if(!service.ExisteDB())service.DBInitialization();

            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Forms.MainScreen(service));
        }
    }
}
