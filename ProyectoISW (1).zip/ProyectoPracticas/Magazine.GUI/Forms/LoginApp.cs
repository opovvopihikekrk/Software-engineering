﻿using Magazine.Services;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Magazine.GUI.Forms
{
    public partial class LoginApp : Form
    {

        protected NewUserForm NewUserForm;
        private IMagazineService service;

        public LoginApp(IMagazineService service)
        {
            InitializeComponent();
            this.service = service;
        }

        private void buttonLogin_Click(object sender, EventArgs e)
        {
            TryLogin();
        }

        private void buttonRegister_Click(object sender, EventArgs e)
        {
            NewUserForm registerForm = new NewUserForm(service);
            registerForm.ShowDialog();
        }

        private void LoginApp_Load(object sender, EventArgs e)
        {
            
        }

        private void onCheckIssuesClicked(object sender, EventArgs e)
        {
            ListIssue listIssueForm = new ListIssue(service);
            listIssueForm.ShowDialog();
        }

        private void enterPressed(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                TryLogin();
            }
        }

        private void TryLogin()
        {
            try
            {
                service.Login(textBoxLogin.Text, textBoxPass.Text);
                this.Close();
            }
            catch (ServiceException err)
            {
                DialogResult error = MessageBox.Show(err.Message.ToString(), "Error");
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void enterDownUser(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                textBoxPass.Focus();
            }
        }
    }
}
