﻿using Magazine.Entities;
using Magazine.Services;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Magazine.GUI.Forms
{
    public partial class ListIssue : Form
    {
        private IMagazineService service;
        public ListIssue(IMagazineService service)
        {
            InitializeComponent();
            this.service = service; 
        }
        public void LoadData(ICollection<Paper> collection)
        {
            foreach (Paper p in collection)
            {
                String coAuthors = "";
                foreach (Person coAuthor in p.CoAuthors)
                {
                    String s = coAuthor.Name + " " + coAuthor.Surname;
                    coAuthors += " " + s;
                }
                dataGridView1.Rows.Add(p.Title, p.Responsible.Name, coAuthors);
            }

        }

        private void ListIssue_Load(object sender, EventArgs e)
        {

        }

        private void onCheckButtonClicked(object sender, EventArgs e)
        {
            try
            {
                dataGridView1.Rows.Clear();
                Issue i = service.GetIssueByNumber(int.Parse(issueText.Text));
                if (i != null && service.isPublished(i)) {
                    LoadData(service.GetPublishedPapersFromIssue(i)); 
                    priceLabel.Text = i.Price.ToString(); 
                }
                else { DialogResult error = MessageBox.Show("Issue number does not exists."); }
            }
            catch (FormatException err) { DialogResult error = MessageBox.Show("Please, enter a valid number."); }
        }
    }
}
