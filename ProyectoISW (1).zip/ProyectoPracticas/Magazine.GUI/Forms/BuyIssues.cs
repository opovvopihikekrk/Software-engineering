﻿using Magazine.Services;
using Magazine.Entities;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Security.Cryptography.X509Certificates;

namespace Magazine.GUI.Forms
{
    public partial class BuyIssues : MagazineFormBase
    {
        ICollection<Issue> issues;
        ICollection<Issue> shoppingCartList;
        

        public BuyIssues(IMagazineService service) : base(service)
        {
            InitializeComponent();
        }

        private void bindingSource1_CurrentChanged(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void LoadBuyIssue(object sender, EventArgs e)
        {
            issues = service.GetAllPublishedIssues();
           
            shoppingCartList = new List<Issue>();
            UpdateList();
        }

        private void issueToCartB(object sender, EventArgs e)
        {
            try
            {
                Issue issue = issues.ElementAt(IssueGridView.CurrentCell.RowIndex);
                issues.Remove(issue);
                shoppingCartList.Add(issue);
                UpdateList();
                PresioLabel.Text = service.GetShoppingCartPrice(shoppingCartList).ToString() + " €";
            }
            catch (NullReferenceException err) {
                DialogResult error = MessageBox.Show("No se ha podido añadir el elemento a la cesta");
            }

            //shoppingCartList.Add(new { ds_purchaseIssue = number });
            //issuesList.Remove(bindingIss);
            //bindingShoppingCart.DataSource = shoppingCartList;

        }
        private void UpdateList()
        {
            BindingList<object> bindingIssues = new BindingList<object>();
            BindingList<object> bindingCart = new BindingList<object>();
            foreach (Issue issue in issues)
            {
                bindingIssues.Add(new
                {
                    ds_Number = issue.Number,
                    ds_Discount = issue.Discount,
                    ds_Price = issue.Price
                });
            }

            foreach (Issue issue in shoppingCartList)
            {
                bindingCart.Add(new { ds_SC = issue.Number });
            }
            IssuesBS.DataSource = bindingIssues;
            CartBS.DataSource = bindingCart;
        }


        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private void ShoppingCartGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void cartToIssuesB(object sender, EventArgs e)
        {
            if (CartBS.Current == null) return;
            Issue issue = shoppingCartList.ElementAt(SCGridView.CurrentCell.RowIndex);
            issues.Add(issue);
            shoppingCartList.Remove(issue);
            UpdateList();
            PresioLabel.Text = service.GetShoppingCartPrice(shoppingCartList).ToString() + " €";
        }

        private void IssuesBS_CurrentChanged_1(object sender, EventArgs e)
        {
            if (IssuesBS.Count == 0) buyB.Enabled = false;
            else buyB.Enabled = true;   
        }

        private void CartBS_CurrentChanged(object sender, EventArgs e)
        {
            if (CartBS.Count == 0) unBuyB.Enabled = false;
            else unBuyB.Enabled = true;
        }
    }
}
