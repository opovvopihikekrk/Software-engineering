﻿using Magazine.Services;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Magazine.GUI.Forms
{
    public partial class MagazineFormBase : Form
    {
        protected IMagazineService service;
        public MagazineFormBase()
        {
            InitializeComponent();
            
        }

        public MagazineFormBase(IMagazineService service) : this()
        {
            this.service = service;
        }

        private void buildIssueToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (!service.IsChiefEditor())
            {
                DialogResult error = MessageBox.Show("This user does not have access to this option", "Error");
                return;
            }
            MakeIssue issueForm = new MakeIssue(service);
            issueForm.Show();
            this.Hide();
        }
        
        private void listPapersToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (!service.IsChiefEditor())
            {
                DialogResult error = MessageBox.Show("This user does not have access to this option", "Error");
                return;
            }
            ListAllPapers papersForm = new ListAllPapers(service);
            papersForm.Show();
            this.Hide();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void evaluateToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (!service.IsEditor())
            {
                DialogResult error = MessageBox.Show("This user does not have access to this option", "Error");
                return;
            }
            EvaluatePaper evaluatePaper = new EvaluatePaper(service);
            evaluatePaper.Show();
            this.Hide();
        }

        private void submitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (!service.IsAutor()) {
                DialogResult error = MessageBox.Show("This user does not have access to this option", "Error");
                return;
            }
            AddPaperForm addPaper = new AddPaperForm(service);
            addPaper.Show();
            this.Hide();
        }

        private void LogOutButtonClick(object sender, EventArgs e)
        {
           MainScreen ms = new MainScreen(service);
           this.Hide();
           ms.Show();
           

        }

        private void MagazineFormBase_Load(object sender, EventArgs e)
        {

        }
        private void Form1_Shown(Object sender, EventArgs e)
        {
            try { userText.Text = "Logged user: " + service.LoggedUser.Login; }
            catch { userText.Text = "Logged user: "; }
        }
        private void papersToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void buyToolStripMenuItem_Click(object sender, EventArgs e)
        {
            BuyIssues buyIssues = new BuyIssues(service);
            buyIssues.Show();
            this.Hide();
        }
    }
}
