﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Magazine.Entities;
using Magazine.Services;

namespace Magazine.GUI.Forms
{
    public partial class ModifyPaper : Form
    {
        protected Paper evaluatePaper;
        private IMagazineService service;
        private EvaluatePaper guardarDatos;
        public ModifyPaper(Paper evaluatePaper, IMagazineService service, EvaluatePaper guardarDatos)
        {
            InitializeComponent();
            this.evaluatePaper = evaluatePaper;
            this.service = service;
            this.guardarDatos = guardarDatos;
        }

        private void LoadData()
        {
            areaText.Text = evaluatePaper.BelongingArea.Name;
            paperText.Text = evaluatePaper.Title;
        }

        private void ModificarPaper_Load(object sender, EventArgs e)
        {
            LoadData();
        }
            protected virtual bool fieldsOK()
        {
            return !string.IsNullOrEmpty(commentTextBox.Text);
        }
   
        public virtual void Clear() 
        {
            areaText.Text = "";
            paperText.Text = "";
            commentTextBox.Clear();
        }

        private void acceptButton_click(object sender, EventArgs e)
        {
            if (fieldsOK())
            {
                try
                {
                    service.AddEvaluation(evaluatePaper, DateTime.Now, commentTextBox.Text, true);
                    guardarDatos.LoadDataGridView();
                    this.Close();
                }
                catch (ServiceException err)
                {
                    DialogResult error = MessageBox.Show(err.Message.ToString(), "Error");
                }
            }
            else MessageBox.Show("Missing Fields", "Error");
        }

        private void rejectButton_click(object sender, EventArgs e)
        {
            if (fieldsOK())
            {
                try
                {
                    service.AddEvaluation(evaluatePaper, DateTime.Now, commentTextBox.Text, false);
                    guardarDatos.LoadDataGridView();
                    this.Close();
                }
                catch (ServiceException err) {
                    DialogResult error = MessageBox.Show(err.Message.ToString(), "Error");
                }
            }
            else MessageBox.Show("Missing Fields", "Error");
        }
    }
}
