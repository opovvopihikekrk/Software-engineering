﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.SymbolStore;
using System.Drawing;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using Magazine.Entities;
using Magazine.Services;

namespace Magazine.GUI.Forms
{
    
    public partial class NewUserForm : Form
    {
        private IMagazineService service;
        public NewUserForm(IMagazineService service)
        {
            InitializeComponent();
            initializeMyGroupBox();
            this.service = service;
        }

        private void initializeMyGroupBox()
        {
            groupBox1.Controls.Add(AlertedRadioButtonYES);
            groupBox1.Controls.Add(AlertedRadioButtonNO);
            Controls.Add(groupBox1);

            groupBox2.Controls.Add(radioButtonSubscribed);
            groupBox2.Controls.Add(radioButtonNotSubscribed);
            Controls.Add(groupBox2);
        }

        private void AlertedHover(object sender, EventArgs e)
        {
            AlertedtextBox.Visible = true;
        }

        private void onClickAddUserButton(object sender, EventArgs e)
        {
            try
            {
                service.AddUser(DNItextBox.Text, NametextBox.Text, SurNametextBox.Text,
                    AlertedRadioButtonYES.Checked, AreasOfInteresttextBox.Text, EmailtextBox.Text,
                    UserNametextBox.Text, radioButtonSubscribed.Checked, PasswordtextBox.Text);
                this.Close();

            }
            catch (ServiceException err) {
                DialogResult error = MessageBox.Show(err.Message.ToString(), "Error");
            }
                
        }

        protected virtual bool fieldsOK()
        {
            return
                !string.IsNullOrEmpty(DNItextBox.Text) &&
                DNItextBox.Text.Length == 9 &&
                !string.IsNullOrEmpty(NametextBox.Text) &&
                !string.IsNullOrEmpty(SurNametextBox.Text) &&
                !string.IsNullOrEmpty(AreasOfInteresttextBox.Text) &&
                !string.IsNullOrEmpty(EmailtextBox.Text) &&
                EmailtextBox.Text.Contains("@") &&
                EmailtextBox.Text.Contains(".") &&
                !string.IsNullOrEmpty(UserNametextBox.Text) &&
                !string.IsNullOrEmpty(PasswordtextBox.Text);
        }

        private void textChanged(object sender, EventArgs e)
        {
            if (fieldsOK()) AddUserbutton.Enabled = true;
            else AddUserbutton.Enabled = false;
        }

        private void AlertedLeave(object sender, EventArgs e)
        {
            AlertedtextBox.Visible = false;
        }

        private void NewUserForm_Load(object sender, EventArgs e)
        {

        }
    }
}
