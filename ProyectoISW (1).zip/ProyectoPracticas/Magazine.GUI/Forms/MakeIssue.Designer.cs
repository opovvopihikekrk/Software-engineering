﻿namespace Magazine.GUI.Forms
{
    partial class MakeIssue
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Confirmbutton = new System.Windows.Forms.Button();
            this.Publishedbutton = new System.Windows.Forms.Button();
            this.Removebutton = new System.Windows.Forms.Button();
            this.IssuedataGridView = new System.Windows.Forms.DataGridView();
            this.Title = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PublisheddataGridView = new System.Windows.Forms.DataGridView();
            this.Title2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Areaslabel = new System.Windows.Forms.Label();
            this.AreascomboBox = new System.Windows.Forms.ComboBox();
            this.issueLabel = new System.Windows.Forms.Label();
            this.areaLabel = new System.Windows.Forms.Label();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.priceText = new System.Windows.Forms.TextBox();
            this.discountText = new System.Windows.Forms.TextBox();
            this.labelMakeIssue = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.IssuedataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PublisheddataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // Confirmbutton
            // 
            this.Confirmbutton.Location = new System.Drawing.Point(845, 485);
            this.Confirmbutton.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Confirmbutton.Name = "Confirmbutton";
            this.Confirmbutton.Size = new System.Drawing.Size(75, 23);
            this.Confirmbutton.TabIndex = 0;
            this.Confirmbutton.Text = "Confirm";
            this.Confirmbutton.UseVisualStyleBackColor = true;
            this.Confirmbutton.Click += new System.EventHandler(this.ConfirmOnClick);
            // 
            // Publishedbutton
            // 
            this.Publishedbutton.Enabled = false;
            this.Publishedbutton.Location = new System.Drawing.Point(379, 259);
            this.Publishedbutton.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Publishedbutton.Name = "Publishedbutton";
            this.Publishedbutton.Size = new System.Drawing.Size(75, 23);
            this.Publishedbutton.TabIndex = 1;
            this.Publishedbutton.Text = "<-";
            this.Publishedbutton.UseVisualStyleBackColor = true;
            this.Publishedbutton.Click += new System.EventHandler(this.PublishedClick);
            // 
            // Removebutton
            // 
            this.Removebutton.Enabled = false;
            this.Removebutton.Location = new System.Drawing.Point(379, 326);
            this.Removebutton.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Removebutton.Name = "Removebutton";
            this.Removebutton.Size = new System.Drawing.Size(75, 23);
            this.Removebutton.TabIndex = 2;
            this.Removebutton.Text = "->";
            this.Removebutton.UseVisualStyleBackColor = true;
            this.Removebutton.Click += new System.EventHandler(this.RemoveClick);
            // 
            // IssuedataGridView
            // 
            this.IssuedataGridView.AllowUserToAddRows = false;
            this.IssuedataGridView.AllowUserToDeleteRows = false;
            this.IssuedataGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.IssuedataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.IssuedataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Title});
            this.IssuedataGridView.Location = new System.Drawing.Point(59, 122);
            this.IssuedataGridView.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.IssuedataGridView.Name = "IssuedataGridView";
            this.IssuedataGridView.ReadOnly = true;
            this.IssuedataGridView.RowHeadersVisible = false;
            this.IssuedataGridView.RowHeadersWidth = 51;
            this.IssuedataGridView.RowTemplate.Height = 24;
            this.IssuedataGridView.Size = new System.Drawing.Size(240, 338);
            this.IssuedataGridView.TabIndex = 3;
            this.IssuedataGridView.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.IssuedataGridView_CellContentClick);
            // 
            // Title
            // 
            this.Title.DataPropertyName = "dsRemove";
            this.Title.HeaderText = "Title";
            this.Title.MinimumWidth = 6;
            this.Title.Name = "Title";
            this.Title.ReadOnly = true;
            // 
            // PublisheddataGridView
            // 
            this.PublisheddataGridView.AllowUserToAddRows = false;
            this.PublisheddataGridView.AllowUserToDeleteRows = false;
            this.PublisheddataGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.PublisheddataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.PublisheddataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Title2});
            this.PublisheddataGridView.Location = new System.Drawing.Point(534, 122);
            this.PublisheddataGridView.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.PublisheddataGridView.MultiSelect = false;
            this.PublisheddataGridView.Name = "PublisheddataGridView";
            this.PublisheddataGridView.ReadOnly = true;
            this.PublisheddataGridView.RowHeadersVisible = false;
            this.PublisheddataGridView.RowHeadersWidth = 51;
            this.PublisheddataGridView.RowTemplate.Height = 24;
            this.PublisheddataGridView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.PublisheddataGridView.Size = new System.Drawing.Size(240, 338);
            this.PublisheddataGridView.TabIndex = 4;
            // 
            // Title2
            // 
            this.Title2.DataPropertyName = "dsPublished";
            this.Title2.HeaderText = "Title";
            this.Title2.MinimumWidth = 6;
            this.Title2.Name = "Title2";
            this.Title2.ReadOnly = true;
            // 
            // Areaslabel
            // 
            this.Areaslabel.AutoSize = true;
            this.Areaslabel.Location = new System.Drawing.Point(118, 63);
            this.Areaslabel.Name = "Areaslabel";
            this.Areaslabel.Size = new System.Drawing.Size(46, 16);
            this.Areaslabel.TabIndex = 5;
            this.Areaslabel.Text = "Areas:";
            this.Areaslabel.Click += new System.EventHandler(this.Areaslabel_Click);
            // 
            // AreascomboBox
            // 
            this.AreascomboBox.FormattingEnabled = true;
            this.AreascomboBox.Location = new System.Drawing.Point(178, 55);
            this.AreascomboBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.AreascomboBox.Name = "AreascomboBox";
            this.AreascomboBox.Size = new System.Drawing.Size(121, 24);
            this.AreascomboBox.TabIndex = 6;
            this.AreascomboBox.SelectedIndexChanged += new System.EventHandler(this.ComboBoxIndexChanged);
            // 
            // issueLabel
            // 
            this.issueLabel.AutoSize = true;
            this.issueLabel.Location = new System.Drawing.Point(104, 98);
            this.issueLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.issueLabel.Name = "issueLabel";
            this.issueLabel.Size = new System.Drawing.Size(140, 16);
            this.issueLabel.TabIndex = 7;
            this.issueLabel.Text = "Issue selected papers";
            // 
            // areaLabel
            // 
            this.areaLabel.AutoSize = true;
            this.areaLabel.Location = new System.Drawing.Point(585, 98);
            this.areaLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.areaLabel.Name = "areaLabel";
            this.areaLabel.Size = new System.Drawing.Size(134, 16);
            this.areaLabel.TabIndex = 8;
            this.areaLabel.Text = "Area pending papers";
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Checked = false;
            this.dateTimePicker1.Location = new System.Drawing.Point(474, 58);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(200, 22);
            this.dateTimePicker1.TabIndex = 9;
            this.dateTimePicker1.Value = new System.DateTime(2023, 1, 30, 0, 0, 0, 0);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(349, 63);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(105, 16);
            this.label1.TabIndex = 10;
            this.label1.Text = "Publication Date";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(531, 488);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(38, 16);
            this.label2.TabIndex = 11;
            this.label2.Text = "Price";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(668, 488);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(82, 16);
            this.label3.TabIndex = 12;
            this.label3.Text = "Discount (%)";
            // 
            // priceText
            // 
            this.priceText.Location = new System.Drawing.Point(591, 482);
            this.priceText.Name = "priceText";
            this.priceText.Size = new System.Drawing.Size(45, 22);
            this.priceText.TabIndex = 13;
            // 
            // discountText
            // 
            this.discountText.Location = new System.Drawing.Point(766, 485);
            this.discountText.Name = "discountText";
            this.discountText.Size = new System.Drawing.Size(41, 22);
            this.discountText.TabIndex = 14;
            // 
            // labelMakeIssue
            // 
            this.labelMakeIssue.AutoSize = true;
            this.labelMakeIssue.Location = new System.Drawing.Point(842, 510);
            this.labelMakeIssue.Name = "labelMakeIssue";
            this.labelMakeIssue.Size = new System.Drawing.Size(204, 48);
            this.labelMakeIssue.TabIndex = 15;
            this.labelMakeIssue.Text = "(You need to confirm\r\nall the Papers you want to include\r\nfrom all Areas)";
            this.labelMakeIssue.Click += new System.EventHandler(this.labelMakeIssue_Click);
            // 
            // MakeIssue
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1243, 607);
            this.Controls.Add(this.labelMakeIssue);
            this.Controls.Add(this.discountText);
            this.Controls.Add(this.priceText);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.areaLabel);
            this.Controls.Add(this.issueLabel);
            this.Controls.Add(this.AreascomboBox);
            this.Controls.Add(this.Areaslabel);
            this.Controls.Add(this.PublisheddataGridView);
            this.Controls.Add(this.IssuedataGridView);
            this.Controls.Add(this.Removebutton);
            this.Controls.Add(this.Publishedbutton);
            this.Controls.Add(this.Confirmbutton);
            this.Margin = new System.Windows.Forms.Padding(4, 2, 4, 2);
            this.MaximumSize = new System.Drawing.Size(1261, 654);
            this.MinimumSize = new System.Drawing.Size(1261, 654);
            this.Name = "MakeIssue";
            this.StartPosition = System.Windows.Forms.FormStartPosition.WindowsDefaultBounds;
            this.Text = "MakeIssue";
            this.Load += new System.EventHandler(this.MakeIssue_Load);
            this.Controls.SetChildIndex(this.Confirmbutton, 0);
            this.Controls.SetChildIndex(this.Publishedbutton, 0);
            this.Controls.SetChildIndex(this.Removebutton, 0);
            this.Controls.SetChildIndex(this.IssuedataGridView, 0);
            this.Controls.SetChildIndex(this.PublisheddataGridView, 0);
            this.Controls.SetChildIndex(this.Areaslabel, 0);
            this.Controls.SetChildIndex(this.AreascomboBox, 0);
            this.Controls.SetChildIndex(this.issueLabel, 0);
            this.Controls.SetChildIndex(this.areaLabel, 0);
            this.Controls.SetChildIndex(this.dateTimePicker1, 0);
            this.Controls.SetChildIndex(this.label1, 0);
            this.Controls.SetChildIndex(this.label2, 0);
            this.Controls.SetChildIndex(this.label3, 0);
            this.Controls.SetChildIndex(this.priceText, 0);
            this.Controls.SetChildIndex(this.discountText, 0);
            this.Controls.SetChildIndex(this.labelMakeIssue, 0);
            ((System.ComponentModel.ISupportInitialize)(this.IssuedataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PublisheddataGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Confirmbutton;
        private System.Windows.Forms.Button Publishedbutton;
        private System.Windows.Forms.Button Removebutton;
        private System.Windows.Forms.DataGridView IssuedataGridView;
        private System.Windows.Forms.DataGridView PublisheddataGridView;
        private System.Windows.Forms.Label Areaslabel;
        private System.Windows.Forms.ComboBox AreascomboBox;
        private System.Windows.Forms.DataGridViewTextBoxColumn Title;
        private System.Windows.Forms.DataGridViewTextBoxColumn Title2;
        private System.Windows.Forms.Label issueLabel;
        private System.Windows.Forms.Label areaLabel;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox priceText;
        private System.Windows.Forms.TextBox discountText;
        private System.Windows.Forms.Label labelMakeIssue;
    }
}