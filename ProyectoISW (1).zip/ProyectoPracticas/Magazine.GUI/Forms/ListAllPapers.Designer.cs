﻿namespace Magazine.GUI.Forms
{
    partial class ListAllPapers
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.areaCol = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.titleCol = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.autorCol = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.statusCol = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.coAuthorsCol = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.issueText = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AllowUserToResizeRows = false;
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView1.BackgroundColor = System.Drawing.SystemColors.Control;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.areaCol,
            this.titleCol,
            this.autorCol,
            this.statusCol,
            this.coAuthorsCol});
            this.dataGridView1.Location = new System.Drawing.Point(0, 89);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(4);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowHeadersVisible = false;
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.Size = new System.Drawing.Size(1243, 683);
            this.dataGridView1.TabIndex = 0;
            // 
            // areaCol
            // 
            this.areaCol.DataPropertyName = "areaCol";
            this.areaCol.HeaderText = "Area";
            this.areaCol.MinimumWidth = 6;
            this.areaCol.Name = "areaCol";
            this.areaCol.ReadOnly = true;
            // 
            // titleCol
            // 
            this.titleCol.DataPropertyName = "titleCol";
            this.titleCol.HeaderText = "Title";
            this.titleCol.MinimumWidth = 6;
            this.titleCol.Name = "titleCol";
            this.titleCol.ReadOnly = true;
            // 
            // autorCol
            // 
            this.autorCol.DataPropertyName = "autorCol";
            this.autorCol.HeaderText = "Autor";
            this.autorCol.MinimumWidth = 6;
            this.autorCol.Name = "autorCol";
            this.autorCol.ReadOnly = true;
            // 
            // statusCol
            // 
            this.statusCol.DataPropertyName = "statusCol";
            this.statusCol.HeaderText = "Status";
            this.statusCol.MinimumWidth = 6;
            this.statusCol.Name = "statusCol";
            this.statusCol.ReadOnly = true;
            // 
            // coAuthorsCol
            // 
            this.coAuthorsCol.DataPropertyName = "coAuthorsCol";
            this.coAuthorsCol.HeaderText = "CoAuthors";
            this.coAuthorsCol.MinimumWidth = 6;
            this.coAuthorsCol.Name = "coAuthorsCol";
            this.coAuthorsCol.ReadOnly = true;
            // 
            // issueText
            // 
            this.issueText.Location = new System.Drawing.Point(166, 49);
            this.issueText.Name = "issueText";
            this.issueText.Size = new System.Drawing.Size(100, 22);
            this.issueText.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(51, 52);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(87, 16);
            this.label1.TabIndex = 3;
            this.label1.Text = "Issue number";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(303, 48);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 4;
            this.button1.Text = "OK";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.onOKClick);
            // 
            // ListAllPapers
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1243, 607);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.issueText);
            this.Controls.Add(this.dataGridView1);
            this.Margin = new System.Windows.Forms.Padding(4, 2, 4, 2);
            this.MaximumSize = new System.Drawing.Size(1261, 654);
            this.MinimumSize = new System.Drawing.Size(1261, 654);
            this.Name = "ListAllPapers";
            this.Text = "AllPapers";
            this.Load += new System.EventHandler(this.ListAllPapers_Load);
            this.Controls.SetChildIndex(this.dataGridView1, 0);
            this.Controls.SetChildIndex(this.issueText, 0);
            this.Controls.SetChildIndex(this.label1, 0);
            this.Controls.SetChildIndex(this.button1, 0);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridViewTextBoxColumn areaCol;
        private System.Windows.Forms.DataGridViewTextBoxColumn titleCol;
        private System.Windows.Forms.DataGridViewTextBoxColumn autorCol;
        private System.Windows.Forms.DataGridViewTextBoxColumn statusCol;
        private System.Windows.Forms.DataGridViewTextBoxColumn coAuthorsCol;
        private System.Windows.Forms.TextBox issueText;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button1;
    }
}