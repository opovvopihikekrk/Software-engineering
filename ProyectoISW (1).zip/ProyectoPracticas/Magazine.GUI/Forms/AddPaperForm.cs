﻿using Magazine.Services;
using Magazine.Entities;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Magazine.GUI.Forms
{
    
    public partial class AddPaperForm : MagazineFormBase
    {
        public AddPaperForm(IMagazineService service) : base(service)
        {
            InitializeComponent();
        }

        private void checkClicked(object sender, EventArgs e)
        {
            if (service.ExistsArea(areaText.Text))
            {
                groupBoxCA.Enabled = true;
                TitleText.Enabled = true;
                goButton.Enabled = true;
                areaText.Enabled = false;
            }
            else 
            {
                DialogResult error = MessageBox.Show("Speficied Area does not exists", "Error");
            }
        }

        private void goClicked(object sender, EventArgs e)
        {
            if (TitleText.Text == string.Empty) {
                DialogResult error = MessageBox.Show("Please enter a title", "Error");
                return;
            }
            //service.AddPaper(service.LoggedUser, TitleText.Text, DateTime.Now, areaText.Text, );
            ICollection<Person> l = new List<Person>();
            try
            {
                if (CA1id.Text != string.Empty && CA1name.Text != string.Empty && CA1surname.Text != string.Empty)
                {
                    service.checkCoauthor(CA1id.Text, CA1name.Text, CA1surname.Text);
                    l.Add(service.GetPersonById(CA1id.Text));
                }
                if (CA2id.Text != string.Empty && CA2name.Text != string.Empty && CA2surname.Text != string.Empty)
                {
                    service.checkCoauthor(CA2id.Text, CA2name.Text, CA2surname.Text);
                    l.Add(service.GetPersonById(CA2id.Text));
                }
                if (CA3id.Text != string.Empty && CA3name.Text != string.Empty && CA3surname.Text != string.Empty)
                {
                    service.checkCoauthor(CA3id.Text, CA3name.Text, CA3surname.Text);
                    l.Add(service.GetPersonById(CA3id.Text));
                }
                if (CA4id.Text != string.Empty && CA4name.Text != string.Empty && CA4surname.Text != string.Empty)
                {
                    service.checkCoauthor(CA4id.Text, CA3name.Text, CA4surname.Text);
                    l.Add(service.GetPersonById(CA4id.Text));
                }

                service.AddPaper(service.LoggedUser, TitleText.Text, DateTime.Now, areaText.Text, l);
                DialogResult numIssue = MessageBox.Show(this,
                    "Paper added",
                    "Sucess",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information);

                groupBoxCA.Enabled = false;
                TitleText.Enabled = false;
                goButton.Enabled = false;
                areaText.Enabled = true;
                TitleText.Text = "";

            }
            catch (ServiceException err) { 
                DialogResult error = MessageBox.Show(err.Message.ToString(), "Error");
                l.Clear();
            }

        }

        private void AddPaperForm_Load(object sender, EventArgs e)
        {

        }
    }
}
