﻿using Magazine.Services;
using Magazine.Entities;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Security.Cryptography.X509Certificates;

namespace Magazine.GUI.Forms
{
    public partial class EvaluatePaper : MagazineFormBase
    {
        Area selectedArea;
        ICollection<Paper> selectedAreaPapers;
        public EvaluatePaper(IMagazineService service) : base(service)
        {
            InitializeComponent();
        }
        public void LoadData()
        {
            ICollection<Area> areas = service.GetAllAreas();
            areaBox.Items.Clear();
            if (areas != null)
                foreach (Area c in service.GetAllAreas())
                    areaBox.Items.Add(c.Name);
            areaBox.SelectedIndex = -1;
            areaBox.ResetText();
            paperBindingSource.DataSource = null;
        }
        private void paperGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (service.IsEditorFromArea(selectedArea)){
                ModifyPaper modifyPaper = new ModifyPaper(selectedAreaPapers.ElementAt(e.RowIndex), service, this);
                modifyPaper.ShowDialog();
            } else
            {
                DialogResult error = MessageBox.Show("No eres editor del Area: " + selectedArea.Name, "Error");
            }
        }

        private void areaBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            LoadDataGridView();
        }

        public void LoadDataGridView()
        {
            string name = (string)areaBox.SelectedItem;
            selectedArea = service.GetAreaByName(name);
            selectedAreaPapers = service.GetPapersFromArea(selectedArea, true, false);

            areaEditorUser.Text = "Area editor: " + selectedArea.Editor.Name;

            BindingList<object> bindinglist = new BindingList<object>();
            foreach (Paper p in selectedAreaPapers)
            {
                bindinglist.Add(new
                {
                    ds_Title = p.Title,
                    ds_Author = p.Responsible.Name,
                    ds_Ud = p.UploadDate
                });
            }
            paperBindingSource.DataSource = bindinglist;
        }
        private void EvaluatePaper_Load(object sender, EventArgs e)
        {
            LoadData();
        }
    }
}
