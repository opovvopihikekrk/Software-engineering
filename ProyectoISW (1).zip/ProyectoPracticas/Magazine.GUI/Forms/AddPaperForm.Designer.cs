﻿namespace Magazine.GUI.Forms
{
    partial class AddPaperForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.areaText = new System.Windows.Forms.TextBox();
            this.checkbutton = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.TitleText = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.CA1id = new System.Windows.Forms.TextBox();
            this.CA1name = new System.Windows.Forms.TextBox();
            this.CA1surname = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.CA2id = new System.Windows.Forms.TextBox();
            this.CA2name = new System.Windows.Forms.TextBox();
            this.CA2surname = new System.Windows.Forms.TextBox();
            this.CA3id = new System.Windows.Forms.TextBox();
            this.CA3name = new System.Windows.Forms.TextBox();
            this.CA3surname = new System.Windows.Forms.TextBox();
            this.CA4id = new System.Windows.Forms.TextBox();
            this.CA4name = new System.Windows.Forms.TextBox();
            this.CA4surname = new System.Windows.Forms.TextBox();
            this.goButton = new System.Windows.Forms.Button();
            this.groupBoxCA = new System.Windows.Forms.GroupBox();
            this.groupBoxCA.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(164, 159);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(36, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "Area";
            // 
            // areaText
            // 
            this.areaText.Location = new System.Drawing.Point(211, 154);
            this.areaText.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.areaText.Name = "areaText";
            this.areaText.Size = new System.Drawing.Size(132, 22);
            this.areaText.TabIndex = 1;
            // 
            // checkbutton
            // 
            this.checkbutton.Location = new System.Drawing.Point(352, 153);
            this.checkbutton.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.checkbutton.Name = "checkbutton";
            this.checkbutton.Size = new System.Drawing.Size(100, 28);
            this.checkbutton.TabIndex = 2;
            this.checkbutton.Text = "Check";
            this.checkbutton.UseVisualStyleBackColor = true;
            this.checkbutton.Click += new System.EventHandler(this.checkClicked);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(167, 249);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(33, 16);
            this.label2.TabIndex = 3;
            this.label2.Text = "Title";
            // 
            // TitleText
            // 
            this.TitleText.Enabled = false;
            this.TitleText.Location = new System.Drawing.Point(211, 242);
            this.TitleText.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.TitleText.Name = "TitleText";
            this.TitleText.Size = new System.Drawing.Size(132, 22);
            this.TitleText.TabIndex = 4;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(756, 68);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(69, 16);
            this.label3.TabIndex = 5;
            this.label3.Text = "CoAuthors";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(57, 0);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(20, 16);
            this.label4.TabIndex = 6;
            this.label4.Text = "ID";
            // 
            // CA1id
            // 
            this.CA1id.Location = new System.Drawing.Point(8, 23);
            this.CA1id.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.CA1id.Name = "CA1id";
            this.CA1id.Size = new System.Drawing.Size(132, 22);
            this.CA1id.TabIndex = 7;
            // 
            // CA1name
            // 
            this.CA1name.Location = new System.Drawing.Point(185, 23);
            this.CA1name.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.CA1name.Name = "CA1name";
            this.CA1name.Size = new System.Drawing.Size(132, 22);
            this.CA1name.TabIndex = 8;
            // 
            // CA1surname
            // 
            this.CA1surname.Location = new System.Drawing.Point(360, 23);
            this.CA1surname.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.CA1surname.Name = "CA1surname";
            this.CA1surname.Size = new System.Drawing.Size(132, 22);
            this.CA1surname.TabIndex = 9;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(223, 0);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(44, 16);
            this.label5.TabIndex = 10;
            this.label5.Text = "Name";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(395, 0);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(61, 16);
            this.label6.TabIndex = 11;
            this.label6.Text = "Surname";
            // 
            // CA2id
            // 
            this.CA2id.Location = new System.Drawing.Point(8, 55);
            this.CA2id.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.CA2id.Name = "CA2id";
            this.CA2id.Size = new System.Drawing.Size(132, 22);
            this.CA2id.TabIndex = 12;
            // 
            // CA2name
            // 
            this.CA2name.Location = new System.Drawing.Point(185, 55);
            this.CA2name.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.CA2name.Name = "CA2name";
            this.CA2name.Size = new System.Drawing.Size(132, 22);
            this.CA2name.TabIndex = 13;
            // 
            // CA2surname
            // 
            this.CA2surname.Location = new System.Drawing.Point(360, 55);
            this.CA2surname.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.CA2surname.Name = "CA2surname";
            this.CA2surname.Size = new System.Drawing.Size(132, 22);
            this.CA2surname.TabIndex = 14;
            // 
            // CA3id
            // 
            this.CA3id.Location = new System.Drawing.Point(8, 87);
            this.CA3id.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.CA3id.Name = "CA3id";
            this.CA3id.Size = new System.Drawing.Size(132, 22);
            this.CA3id.TabIndex = 15;
            // 
            // CA3name
            // 
            this.CA3name.Location = new System.Drawing.Point(185, 87);
            this.CA3name.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.CA3name.Name = "CA3name";
            this.CA3name.Size = new System.Drawing.Size(132, 22);
            this.CA3name.TabIndex = 16;
            // 
            // CA3surname
            // 
            this.CA3surname.Location = new System.Drawing.Point(360, 87);
            this.CA3surname.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.CA3surname.Name = "CA3surname";
            this.CA3surname.Size = new System.Drawing.Size(132, 22);
            this.CA3surname.TabIndex = 17;
            // 
            // CA4id
            // 
            this.CA4id.Location = new System.Drawing.Point(8, 119);
            this.CA4id.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.CA4id.Name = "CA4id";
            this.CA4id.Size = new System.Drawing.Size(132, 22);
            this.CA4id.TabIndex = 18;
            // 
            // CA4name
            // 
            this.CA4name.AccessibleName = "";
            this.CA4name.Location = new System.Drawing.Point(185, 119);
            this.CA4name.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.CA4name.Name = "CA4name";
            this.CA4name.Size = new System.Drawing.Size(132, 22);
            this.CA4name.TabIndex = 19;
            // 
            // CA4surname
            // 
            this.CA4surname.Location = new System.Drawing.Point(360, 119);
            this.CA4surname.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.CA4surname.Name = "CA4surname";
            this.CA4surname.Size = new System.Drawing.Size(132, 22);
            this.CA4surname.TabIndex = 20;
            // 
            // goButton
            // 
            this.goButton.Enabled = false;
            this.goButton.Location = new System.Drawing.Point(352, 240);
            this.goButton.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.goButton.Name = "goButton";
            this.goButton.Size = new System.Drawing.Size(100, 28);
            this.goButton.TabIndex = 21;
            this.goButton.Text = "Add Paper";
            this.goButton.UseVisualStyleBackColor = true;
            this.goButton.Click += new System.EventHandler(this.goClicked);
            // 
            // groupBoxCA
            // 
            this.groupBoxCA.Controls.Add(this.CA1name);
            this.groupBoxCA.Controls.Add(this.CA1id);
            this.groupBoxCA.Controls.Add(this.label4);
            this.groupBoxCA.Controls.Add(this.label5);
            this.groupBoxCA.Controls.Add(this.label6);
            this.groupBoxCA.Controls.Add(this.CA4surname);
            this.groupBoxCA.Controls.Add(this.CA2id);
            this.groupBoxCA.Controls.Add(this.CA3surname);
            this.groupBoxCA.Controls.Add(this.CA4name);
            this.groupBoxCA.Controls.Add(this.CA2surname);
            this.groupBoxCA.Controls.Add(this.CA3id);
            this.groupBoxCA.Controls.Add(this.CA4id);
            this.groupBoxCA.Controls.Add(this.CA3name);
            this.groupBoxCA.Controls.Add(this.CA1surname);
            this.groupBoxCA.Controls.Add(this.CA2name);
            this.groupBoxCA.Enabled = false;
            this.groupBoxCA.Location = new System.Drawing.Point(549, 121);
            this.groupBoxCA.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBoxCA.Name = "groupBoxCA";
            this.groupBoxCA.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBoxCA.Size = new System.Drawing.Size(501, 158);
            this.groupBoxCA.TabIndex = 22;
            this.groupBoxCA.TabStop = false;
            // 
            // AddPaperForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1245, 617);
            this.Controls.Add(this.groupBoxCA);
            this.Controls.Add(this.goButton);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.TitleText);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.checkbutton);
            this.Controls.Add(this.areaText);
            this.Controls.Add(this.label1);
            this.Margin = new System.Windows.Forms.Padding(4, 2, 4, 2);
            this.MaximumSize = new System.Drawing.Size(1261, 656);
            this.MinimumSize = new System.Drawing.Size(1261, 656);
            this.Name = "AddPaperForm";
            this.Text = "AddPaper";
            this.Load += new System.EventHandler(this.AddPaperForm_Load);
            this.Controls.SetChildIndex(this.label1, 0);
            this.Controls.SetChildIndex(this.areaText, 0);
            this.Controls.SetChildIndex(this.checkbutton, 0);
            this.Controls.SetChildIndex(this.label2, 0);
            this.Controls.SetChildIndex(this.TitleText, 0);
            this.Controls.SetChildIndex(this.label3, 0);
            this.Controls.SetChildIndex(this.goButton, 0);
            this.Controls.SetChildIndex(this.groupBoxCA, 0);
            this.groupBoxCA.ResumeLayout(false);
            this.groupBoxCA.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox areaText;
        private System.Windows.Forms.Button checkbutton;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox TitleText;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox CA1id;
        private System.Windows.Forms.TextBox CA1name;
        private System.Windows.Forms.TextBox CA1surname;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox CA2id;
        private System.Windows.Forms.TextBox CA2name;
        private System.Windows.Forms.TextBox CA2surname;
        private System.Windows.Forms.TextBox CA3id;
        private System.Windows.Forms.TextBox CA3name;
        private System.Windows.Forms.TextBox CA3surname;
        private System.Windows.Forms.TextBox CA4id;
        private System.Windows.Forms.TextBox CA4name;
        private System.Windows.Forms.TextBox CA4surname;
        private System.Windows.Forms.Button goButton;
        private System.Windows.Forms.GroupBox groupBoxCA;
    }
}