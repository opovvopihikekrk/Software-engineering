﻿namespace Magazine.GUI.Forms
{
    partial class BuyIssues
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.IssueGridView = new System.Windows.Forms.DataGridView();
            this.IssuesBS = new System.Windows.Forms.BindingSource(this.components);
            this.CartBS = new System.Windows.Forms.BindingSource(this.components);
            this.buyB = new System.Windows.Forms.Button();
            this.unBuyB = new System.Windows.Forms.Button();
            this.Costlabel = new System.Windows.Forms.Label();
            this.PresioLabel = new System.Windows.Forms.Label();
            this.SCGridView = new System.Windows.Forms.DataGridView();
            this.PurchaseIssue = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Number = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Discount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Price = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.IssueGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.IssuesBS)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.CartBS)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.SCGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // IssueGridView
            // 
            this.IssueGridView.AllowUserToAddRows = false;
            this.IssueGridView.AllowUserToDeleteRows = false;
            this.IssueGridView.AutoGenerateColumns = false;
            this.IssueGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.IssueGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.IssueGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Number,
            this.Discount,
            this.Price});
            this.IssueGridView.DataSource = this.IssuesBS;
            this.IssueGridView.Location = new System.Drawing.Point(402, 75);
            this.IssueGridView.Name = "IssueGridView";
            this.IssueGridView.RowHeadersVisible = false;
            this.IssueGridView.RowHeadersWidth = 49;
            this.IssueGridView.RowTemplate.Height = 24;
            this.IssueGridView.Size = new System.Drawing.Size(386, 318);
            this.IssueGridView.TabIndex = 0;
            this.IssueGridView.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // IssuesBS
            // 
            this.IssuesBS.CurrentChanged += new System.EventHandler(this.IssuesBS_CurrentChanged_1);
            // 
            // CartBS
            // 
            this.CartBS.CurrentChanged += new System.EventHandler(this.CartBS_CurrentChanged);
            // 
            // buyB
            // 
            this.buyB.Location = new System.Drawing.Point(291, 200);
            this.buyB.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.buyB.Name = "buyB";
            this.buyB.Size = new System.Drawing.Size(75, 23);
            this.buyB.TabIndex = 2;
            this.buyB.Text = "<-";
            this.buyB.UseVisualStyleBackColor = true;
            this.buyB.Click += new System.EventHandler(this.issueToCartB);
            // 
            // unBuyB
            // 
            this.unBuyB.Enabled = false;
            this.unBuyB.Location = new System.Drawing.Point(291, 239);
            this.unBuyB.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.unBuyB.Name = "unBuyB";
            this.unBuyB.Size = new System.Drawing.Size(75, 23);
            this.unBuyB.TabIndex = 3;
            this.unBuyB.Text = "->";
            this.unBuyB.UseVisualStyleBackColor = true;
            this.unBuyB.Click += new System.EventHandler(this.cartToIssuesB);
            // 
            // Costlabel
            // 
            this.Costlabel.AutoSize = true;
            this.Costlabel.Font = new System.Drawing.Font("Microsoft New Tai Lue", 11.89565F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Costlabel.Location = new System.Drawing.Point(7, 416);
            this.Costlabel.Name = "Costlabel";
            this.Costlabel.Size = new System.Drawing.Size(56, 25);
            this.Costlabel.TabIndex = 4;
            this.Costlabel.Text = "Cost:";
            this.Costlabel.Click += new System.EventHandler(this.label1_Click);
            // 
            // PresioLabel
            // 
            this.PresioLabel.AutoSize = true;
            this.PresioLabel.Font = new System.Drawing.Font("Microsoft Tai Le", 16.27826F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PresioLabel.Location = new System.Drawing.Point(57, 410);
            this.PresioLabel.Name = "PresioLabel";
            this.PresioLabel.Size = new System.Drawing.Size(52, 33);
            this.PresioLabel.TabIndex = 5;
            this.PresioLabel.Text = "0 €";
            this.PresioLabel.Click += new System.EventHandler(this.label1_Click_1);
            // 
            // SCGridView
            // 
            this.SCGridView.AllowUserToAddRows = false;
            this.SCGridView.AllowUserToDeleteRows = false;
            this.SCGridView.AutoGenerateColumns = false;
            this.SCGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.SCGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.SCGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.PurchaseIssue});
            this.SCGridView.DataSource = this.CartBS;
            this.SCGridView.Location = new System.Drawing.Point(12, 75);
            this.SCGridView.Name = "SCGridView";
            this.SCGridView.RowHeadersVisible = false;
            this.SCGridView.RowHeadersWidth = 49;
            this.SCGridView.RowTemplate.Height = 24;
            this.SCGridView.Size = new System.Drawing.Size(241, 318);
            this.SCGridView.TabIndex = 6;
            // 
            // PurchaseIssue
            // 
            this.PurchaseIssue.DataPropertyName = "ds_SC";
            this.PurchaseIssue.HeaderText = "Shopping Cart";
            this.PurchaseIssue.MinimumWidth = 6;
            this.PurchaseIssue.Name = "PurchaseIssue";
            this.PurchaseIssue.ReadOnly = true;
            this.PurchaseIssue.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            // 
            // Number
            // 
            this.Number.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.Number.DataPropertyName = "ds_number";
            this.Number.Frozen = true;
            this.Number.HeaderText = "Number";
            this.Number.MinimumWidth = 6;
            this.Number.Name = "Number";
            this.Number.ReadOnly = true;
            this.Number.Width = 128;
            // 
            // Discount
            // 
            this.Discount.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.Discount.DataPropertyName = "ds_discount";
            this.Discount.Frozen = true;
            this.Discount.HeaderText = "Discount (%)";
            this.Discount.MinimumWidth = 6;
            this.Discount.Name = "Discount";
            this.Discount.ReadOnly = true;
            this.Discount.Width = 127;
            // 
            // Price
            // 
            this.Price.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.Price.DataPropertyName = "ds_price";
            this.Price.Frozen = true;
            this.Price.HeaderText = "Price";
            this.Price.MinimumWidth = 6;
            this.Price.Name = "Price";
            this.Price.ReadOnly = true;
            this.Price.Width = 128;
            // 
            // BuyIssues
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.SCGridView);
            this.Controls.Add(this.PresioLabel);
            this.Controls.Add(this.Costlabel);
            this.Controls.Add(this.unBuyB);
            this.Controls.Add(this.buyB);
            this.Controls.Add(this.IssueGridView);
            this.Name = "BuyIssues";
            this.Text = "Buy Issue";
            this.Load += new System.EventHandler(this.LoadBuyIssue);
            this.Controls.SetChildIndex(this.IssueGridView, 0);
            this.Controls.SetChildIndex(this.buyB, 0);
            this.Controls.SetChildIndex(this.unBuyB, 0);
            this.Controls.SetChildIndex(this.Costlabel, 0);
            this.Controls.SetChildIndex(this.PresioLabel, 0);
            this.Controls.SetChildIndex(this.SCGridView, 0);
            ((System.ComponentModel.ISupportInitialize)(this.IssueGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.IssuesBS)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.CartBS)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.SCGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView IssueGridView;
        private System.Windows.Forms.Button buyB;
        private System.Windows.Forms.Button unBuyB;
        private System.Windows.Forms.BindingSource IssuesBS;
        private System.Windows.Forms.BindingSource CartBS;
        private System.Windows.Forms.Label Costlabel;
        private System.Windows.Forms.Label PresioLabel;
        private System.Windows.Forms.DataGridView SCGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn PurchaseIssue;
        private System.Windows.Forms.DataGridViewTextBoxColumn Number;
        private System.Windows.Forms.DataGridViewTextBoxColumn Discount;
        private System.Windows.Forms.DataGridViewTextBoxColumn Price;
    }
}