﻿namespace Magazine.GUI.Forms
{
    partial class NewUserForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.DNIlabel = new System.Windows.Forms.Label();
            this.DNItextBox = new System.Windows.Forms.TextBox();
            this.Namelabel = new System.Windows.Forms.Label();
            this.NametextBox = new System.Windows.Forms.TextBox();
            this.Surnamelabel = new System.Windows.Forms.Label();
            this.SurNametextBox = new System.Windows.Forms.TextBox();
            this.Alertedlabel = new System.Windows.Forms.Label();
            this.AlertedRadioButtonYES = new System.Windows.Forms.RadioButton();
            this.AlertedRadioButtonNO = new System.Windows.Forms.RadioButton();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.AreasofInterestlabel = new System.Windows.Forms.Label();
            this.AlertedtextBox = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.EmailtextBox = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.UserNametextBox = new System.Windows.Forms.TextBox();
            this.PasswordtextBox = new System.Windows.Forms.TextBox();
            this.AreasOfInteresttextBox = new System.Windows.Forms.TextBox();
            this.AddUserbutton = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.radioButtonNotSubscribed = new System.Windows.Forms.RadioButton();
            this.radioButtonSubscribed = new System.Windows.Forms.RadioButton();
            this.label6 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // DNIlabel
            // 
            this.DNIlabel.AutoSize = true;
            this.DNIlabel.Location = new System.Drawing.Point(74, 17);
            this.DNIlabel.Name = "DNIlabel";
            this.DNIlabel.Size = new System.Drawing.Size(33, 16);
            this.DNIlabel.TabIndex = 0;
            this.DNIlabel.Text = "DNI:";
            // 
            // DNItextBox
            // 
            this.DNItextBox.Location = new System.Drawing.Point(119, 11);
            this.DNItextBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.DNItextBox.Name = "DNItextBox";
            this.DNItextBox.Size = new System.Drawing.Size(132, 22);
            this.DNItextBox.TabIndex = 1;
            this.DNItextBox.TextChanged += new System.EventHandler(this.textChanged);
            // 
            // Namelabel
            // 
            this.Namelabel.AutoSize = true;
            this.Namelabel.Location = new System.Drawing.Point(61, 55);
            this.Namelabel.Name = "Namelabel";
            this.Namelabel.Size = new System.Drawing.Size(47, 16);
            this.Namelabel.TabIndex = 2;
            this.Namelabel.Text = "Name:";
            // 
            // NametextBox
            // 
            this.NametextBox.Location = new System.Drawing.Point(114, 55);
            this.NametextBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.NametextBox.Name = "NametextBox";
            this.NametextBox.Size = new System.Drawing.Size(212, 22);
            this.NametextBox.TabIndex = 3;
            this.NametextBox.TextChanged += new System.EventHandler(this.textChanged);
            // 
            // Surnamelabel
            // 
            this.Surnamelabel.AutoSize = true;
            this.Surnamelabel.Location = new System.Drawing.Point(44, 87);
            this.Surnamelabel.Name = "Surnamelabel";
            this.Surnamelabel.Size = new System.Drawing.Size(64, 16);
            this.Surnamelabel.TabIndex = 4;
            this.Surnamelabel.Text = "Surname:";
            // 
            // SurNametextBox
            // 
            this.SurNametextBox.Location = new System.Drawing.Point(114, 87);
            this.SurNametextBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.SurNametextBox.Name = "SurNametextBox";
            this.SurNametextBox.Size = new System.Drawing.Size(212, 22);
            this.SurNametextBox.TabIndex = 5;
            this.SurNametextBox.TextChanged += new System.EventHandler(this.textChanged);
            // 
            // Alertedlabel
            // 
            this.Alertedlabel.AutoSize = true;
            this.Alertedlabel.Location = new System.Drawing.Point(44, 137);
            this.Alertedlabel.Name = "Alertedlabel";
            this.Alertedlabel.Size = new System.Drawing.Size(60, 16);
            this.Alertedlabel.TabIndex = 6;
            this.Alertedlabel.Text = "Alerted?:";
            this.Alertedlabel.MouseLeave += new System.EventHandler(this.AlertedLeave);
            this.Alertedlabel.MouseHover += new System.EventHandler(this.AlertedHover);
            // 
            // AlertedRadioButtonYES
            // 
            this.AlertedRadioButtonYES.AutoSize = true;
            this.AlertedRadioButtonYES.Checked = true;
            this.AlertedRadioButtonYES.Location = new System.Drawing.Point(5, 21);
            this.AlertedRadioButtonYES.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.AlertedRadioButtonYES.Name = "AlertedRadioButtonYES";
            this.AlertedRadioButtonYES.Size = new System.Drawing.Size(55, 20);
            this.AlertedRadioButtonYES.TabIndex = 7;
            this.AlertedRadioButtonYES.TabStop = true;
            this.AlertedRadioButtonYES.Text = "YES";
            this.AlertedRadioButtonYES.UseVisualStyleBackColor = true;
            // 
            // AlertedRadioButtonNO
            // 
            this.AlertedRadioButtonNO.AutoSize = true;
            this.AlertedRadioButtonNO.Location = new System.Drawing.Point(5, 59);
            this.AlertedRadioButtonNO.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.AlertedRadioButtonNO.Name = "AlertedRadioButtonNO";
            this.AlertedRadioButtonNO.Size = new System.Drawing.Size(48, 20);
            this.AlertedRadioButtonNO.TabIndex = 8;
            this.AlertedRadioButtonNO.TabStop = true;
            this.AlertedRadioButtonNO.Text = "NO";
            this.AlertedRadioButtonNO.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.AlertedRadioButtonYES);
            this.groupBox1.Controls.Add(this.AlertedRadioButtonNO);
            this.groupBox1.Location = new System.Drawing.Point(116, 127);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox1.Size = new System.Drawing.Size(212, 100);
            this.groupBox1.TabIndex = 9;
            this.groupBox1.TabStop = false;
            // 
            // AreasofInterestlabel
            // 
            this.AreasofInterestlabel.AutoSize = true;
            this.AreasofInterestlabel.Location = new System.Drawing.Point(36, 410);
            this.AreasofInterestlabel.Name = "AreasofInterestlabel";
            this.AreasofInterestlabel.Size = new System.Drawing.Size(67, 32);
            this.AreasofInterestlabel.TabIndex = 10;
            this.AreasofInterestlabel.Text = "Areas \r\nof Interest:";
            // 
            // AlertedtextBox
            // 
            this.AlertedtextBox.Location = new System.Drawing.Point(114, 210);
            this.AlertedtextBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.AlertedtextBox.Multiline = true;
            this.AlertedtextBox.Name = "AlertedtextBox";
            this.AlertedtextBox.ReadOnly = true;
            this.AlertedtextBox.Size = new System.Drawing.Size(212, 74);
            this.AlertedtextBox.TabIndex = 11;
            this.AlertedtextBox.Text = "Here you can select wether you want to receive \r\nthe latest news on the email pro" +
    "vided below";
            this.AlertedtextBox.Visible = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(59, 462);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(44, 16);
            this.label1.TabIndex = 12;
            this.label1.Text = "Email:";
            // 
            // EmailtextBox
            // 
            this.EmailtextBox.Location = new System.Drawing.Point(116, 456);
            this.EmailtextBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.EmailtextBox.Name = "EmailtextBox";
            this.EmailtextBox.Size = new System.Drawing.Size(212, 22);
            this.EmailtextBox.TabIndex = 13;
            this.EmailtextBox.TextChanged += new System.EventHandler(this.textChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(29, 521);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(76, 16);
            this.label2.TabIndex = 14;
            this.label2.Text = "UserName:";
            this.label2.UseMnemonic = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(38, 567);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(70, 16);
            this.label3.TabIndex = 15;
            this.label3.Text = "Password:";
            // 
            // UserNametextBox
            // 
            this.UserNametextBox.Location = new System.Drawing.Point(116, 521);
            this.UserNametextBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.UserNametextBox.Name = "UserNametextBox";
            this.UserNametextBox.Size = new System.Drawing.Size(212, 22);
            this.UserNametextBox.TabIndex = 16;
            this.UserNametextBox.TextChanged += new System.EventHandler(this.textChanged);
            // 
            // PasswordtextBox
            // 
            this.PasswordtextBox.Location = new System.Drawing.Point(116, 564);
            this.PasswordtextBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.PasswordtextBox.Name = "PasswordtextBox";
            this.PasswordtextBox.Size = new System.Drawing.Size(212, 22);
            this.PasswordtextBox.TabIndex = 17;
            this.PasswordtextBox.UseSystemPasswordChar = true;
            this.PasswordtextBox.TextChanged += new System.EventHandler(this.textChanged);
            // 
            // AreasOfInteresttextBox
            // 
            this.AreasOfInteresttextBox.Location = new System.Drawing.Point(116, 420);
            this.AreasOfInteresttextBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.AreasOfInteresttextBox.Name = "AreasOfInteresttextBox";
            this.AreasOfInteresttextBox.Size = new System.Drawing.Size(212, 22);
            this.AreasOfInteresttextBox.TabIndex = 18;
            this.AreasOfInteresttextBox.TextChanged += new System.EventHandler(this.textChanged);
            // 
            // AddUserbutton
            // 
            this.AddUserbutton.Enabled = false;
            this.AddUserbutton.Location = new System.Drawing.Point(345, 592);
            this.AddUserbutton.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.AddUserbutton.Name = "AddUserbutton";
            this.AddUserbutton.Size = new System.Drawing.Size(75, 23);
            this.AddUserbutton.TabIndex = 19;
            this.AddUserbutton.Text = "AddUser";
            this.AddUserbutton.UseVisualStyleBackColor = true;
            this.AddUserbutton.Click += new System.EventHandler(this.onClickAddUserButton);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label4.Location = new System.Drawing.Point(116, 35);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(262, 16);
            this.label4.TabIndex = 20;
            this.label4.Text = "8 digits and one letter, example: 11111111C";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label5.Location = new System.Drawing.Point(113, 492);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(154, 16);
            this.label5.TabIndex = 21;
            this.label5.Text = "example@example.com";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.radioButtonNotSubscribed);
            this.groupBox2.Controls.Add(this.radioButtonSubscribed);
            this.groupBox2.Location = new System.Drawing.Point(116, 289);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(200, 100);
            this.groupBox2.TabIndex = 22;
            this.groupBox2.TabStop = false;
            // 
            // radioButtonNotSubscribed
            // 
            this.radioButtonNotSubscribed.AutoSize = true;
            this.radioButtonNotSubscribed.Location = new System.Drawing.Point(6, 61);
            this.radioButtonNotSubscribed.Name = "radioButtonNotSubscribed";
            this.radioButtonNotSubscribed.Size = new System.Drawing.Size(48, 20);
            this.radioButtonNotSubscribed.TabIndex = 1;
            this.radioButtonNotSubscribed.Text = "NO";
            this.radioButtonNotSubscribed.UseVisualStyleBackColor = true;
            // 
            // radioButtonSubscribed
            // 
            this.radioButtonSubscribed.AutoSize = true;
            this.radioButtonSubscribed.Checked = true;
            this.radioButtonSubscribed.Location = new System.Drawing.Point(7, 22);
            this.radioButtonSubscribed.Name = "radioButtonSubscribed";
            this.radioButtonSubscribed.Size = new System.Drawing.Size(55, 20);
            this.radioButtonSubscribed.TabIndex = 0;
            this.radioButtonSubscribed.TabStop = true;
            this.radioButtonSubscribed.Text = "YES";
            this.radioButtonSubscribed.UseVisualStyleBackColor = true;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(20, 315);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(83, 16);
            this.label6.TabIndex = 23;
            this.label6.Text = "Subscribed?";
            // 
            // NewUserForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(432, 626);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.AddUserbutton);
            this.Controls.Add(this.AreasOfInteresttextBox);
            this.Controls.Add(this.PasswordtextBox);
            this.Controls.Add(this.UserNametextBox);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.EmailtextBox);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.AlertedtextBox);
            this.Controls.Add(this.AreasofInterestlabel);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.Alertedlabel);
            this.Controls.Add(this.SurNametextBox);
            this.Controls.Add(this.Surnamelabel);
            this.Controls.Add(this.NametextBox);
            this.Controls.Add(this.Namelabel);
            this.Controls.Add(this.DNItextBox);
            this.Controls.Add(this.DNIlabel);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "NewUserForm";
            this.Text = "New User";
            this.Load += new System.EventHandler(this.NewUserForm_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label DNIlabel;
        private System.Windows.Forms.TextBox DNItextBox;
        private System.Windows.Forms.Label Namelabel;
        private System.Windows.Forms.TextBox NametextBox;
        private System.Windows.Forms.Label Surnamelabel;
        private System.Windows.Forms.TextBox SurNametextBox;
        private System.Windows.Forms.Label Alertedlabel;
        private System.Windows.Forms.RadioButton AlertedRadioButtonYES;
        private System.Windows.Forms.RadioButton AlertedRadioButtonNO;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label AreasofInterestlabel;
        private System.Windows.Forms.TextBox AlertedtextBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox EmailtextBox;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox UserNametextBox;
        private System.Windows.Forms.TextBox PasswordtextBox;
        private System.Windows.Forms.TextBox AreasOfInteresttextBox;
        private System.Windows.Forms.Button AddUserbutton;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.RadioButton radioButtonNotSubscribed;
        private System.Windows.Forms.RadioButton radioButtonSubscribed;
        private System.Windows.Forms.Label label6;
    }
}