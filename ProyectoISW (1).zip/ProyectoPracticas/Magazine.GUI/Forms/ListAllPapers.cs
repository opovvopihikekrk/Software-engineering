﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Magazine.Entities;
using Magazine.Services;

namespace Magazine.GUI.Forms
{
    public partial class ListAllPapers : MagazineFormBase
    {
        public ListAllPapers(IMagazineService service) : base(service)
        {
            InitializeComponent();
        }
        public void LoadData(ICollection<Paper> collection) {
            foreach (Paper p in collection)
            {
                String coAuthors = "";
                foreach (Person coAuthor in p.CoAuthors) {
                    String s = coAuthor.Name + " " + coAuthor.Surname;
                    coAuthors += " " + s;
                }
                dataGridView1.Rows.Add(p.BelongingArea.Name, p.Title, p.Responsible.Name, service.GetPaperStatus(p), coAuthors);
                dataGridView1.Sort(dataGridView1.Columns[0], ListSortDirection.Ascending);
            }
        }

        private void ListAllPapers_Load(object sender, EventArgs e)
        {
            LoadData(service.ListAllArticles());
        }

        private void onOKClick(object sender, EventArgs e)
        {
            try
            {
                dataGridView1.Rows.Clear();
                if (issueText.Text == "") { LoadData(service.ListAllArticles()); }
                else
                {
                    Issue i = service.GetIssueByNumber(int.Parse(issueText.Text));
                    if (i != null) { LoadData(service.GetPublishedPapersFromIssue(i)); }
                    else { DialogResult error = MessageBox.Show("Issue number does not exists."); }
                }
            }
            catch (FormatException err) { DialogResult error = MessageBox.Show("Please, enter a valid number."); }
        }
    }
}
