﻿using Magazine.Entities;
using Magazine.Services;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Magazine.GUI.Forms
{
    public partial class MakeIssue : MagazineFormBase
    {
        private Issue issue;
        private Area selectedArea;
        private ICollection<Paper> selectedPapers;
        private ICollection<Paper> areaPapers;

        public MakeIssue(IMagazineService service) : base(service)
        {
            this.service = service;
            issue = service.CurrentIssue();
            InitializeComponent();
        }

        public void IntializeComboBox()
        {
            ICollection<Area> areas = service.GetAllAreas();
            AreascomboBox.Items.Clear();
            if (areas != null)
                foreach (Area c in service.GetAllAreas())
                    AreascomboBox.Items.Add(c.Name);
            AreascomboBox.SelectedIndex = -1;
            AreascomboBox.ResetText();
            Confirmbutton.Enabled = false;
            //dateTimePicker1.Value = null;
        }

        private void MakeIssue_Load(object sender, EventArgs e)
        {
            IntializeComboBox();

            DialogResult numIssue = MessageBox.Show(this,
                "The Current Issue is:" + issue.Number,
                "Issue Number",
                MessageBoxButtons.OK,
                MessageBoxIcon.Information);

            //selectedPapers = issue.PublishedPapers;
        }

        private void ConfirmOnClick(object sender, EventArgs e)
        {
            try
            {
                service.MakeIssue(issue, selectedPapers, selectedArea);
                if (dateTimePicker1.Checked)
                {
                    if (priceText.Text == "" || discountText.Text == "")
                    {
                        DialogResult error = MessageBox.Show("Please, provide a price and a discount.");
                    }
                    else
                    {
                        if (int.Parse(discountText.Text) > 100 || int.Parse(discountText.Text) < 0) { DialogResult error = MessageBox.Show("Discount value must be between 0 and 100."); }
                        else { 
                            service.AddPublicationData(issue, dateTimePicker1.Value, int.Parse(priceText.Text), int.Parse(discountText.Text.ToString()));
                            DialogResult numIssue = MessageBox.Show(this,
                                "Cambios guardados",
                                "Éxito",
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Information);
                        }
                    
                    }
                }
                else
                {
                    DialogResult numIssue = MessageBox.Show(this,
                        "Cambios guardados",
                        "Éxito",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Information);
                    AreascomboBox.Enabled = true;
                }
            }
            catch (FormatException) { DialogResult error = MessageBox.Show("Please, provide a valid price and discount."); }
        }

        private void updateList() {
            IssuedataGridView.Rows.Clear();
            PublisheddataGridView.Rows.Clear();
            foreach (Paper p in selectedPapers)
            {
                IssuedataGridView.Rows.Add(p.Title);
            }

            foreach (Paper p in areaPapers)
            {
                PublisheddataGridView.Rows.Add(p.Title);
            }
        }

        private void ComboBoxIndexChanged(object sender, EventArgs e)
        {
            Confirmbutton.Enabled = true;
            string name = (string)AreascomboBox.SelectedItem;
            selectedArea = service.GetAreaByName(name);
            areaPapers = service.GetPapersFromArea(selectedArea, false, true).ToList();
            selectedPapers = service.GetPublishedPapersFromArea(selectedArea, issue);

            if(areaPapers.Count > 0)
            {
                Publishedbutton.Enabled = true;
            } else
            {
                Publishedbutton.Enabled = false;
            }

            if (selectedPapers.Count > 0) 
            { 
                Removebutton.Enabled = true;
            } else
            {
                Removebutton.Enabled = false;
            }
            

            updateList();
        }

        private void PublishedClick(object sender, EventArgs e)
        {
            if (PublisheddataGridView.CurrentCell.RowIndex == -1) return;
            Paper p = areaPapers.ElementAt(PublisheddataGridView.CurrentCell.RowIndex);
            areaPapers.Remove(p);
            if(selectedPapers.Count == 0) Removebutton.Enabled = true;
            selectedPapers.Add(p);
            if(areaPapers.Count == 0) Publishedbutton.Enabled = false;  
            updateList();
        }

        private void RemoveClick(object sender, EventArgs e)
        {
            if (IssuedataGridView.CurrentCell.RowIndex == -1) return;
            Paper p = selectedPapers.ElementAt(IssuedataGridView.CurrentCell.RowIndex);
            if (areaPapers.Count == 0) Publishedbutton.Enabled = true;
            areaPapers.Add(p);
            selectedPapers.Remove(p);
            if (selectedPapers.Count == 0) Removebutton.Enabled = false;
            updateList();
        }

        private void Areaslabel_Click(object sender, EventArgs e)
        {

        }

        private void IssuedataGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void labelMakeIssue_Click(object sender, EventArgs e)
        {

        }
    }
}
