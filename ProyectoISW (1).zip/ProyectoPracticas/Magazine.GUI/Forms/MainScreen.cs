﻿using Magazine.Services;
using Magazine.Entities;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Magazine.GUI.Forms
{
    public partial class MainScreen : MagazineFormBase
    {
        public MainScreen(IMagazineService service) : base (service)
        {
            InitializeComponent();
        }

        private void MainScreen_Load(object sender, EventArgs e) 
        {
            LoginApp login = new LoginApp(service);
            login.ShowDialog();

            if (service.LoggedUser == null) Application.Exit();
        }
    }
}
