﻿namespace Magazine.GUI.Forms
{
    partial class EvaluatePaper
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.paperGridView = new System.Windows.Forms.DataGridView();
            this.Title = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Author = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Upload_Datetime = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.paperBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.label1 = new System.Windows.Forms.Label();
            this.areaBox = new System.Windows.Forms.ComboBox();
            this.areaEditorUser = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.paperGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.paperBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // paperGridView
            // 
            this.paperGridView.AllowUserToAddRows = false;
            this.paperGridView.AllowUserToDeleteRows = false;
            this.paperGridView.AutoGenerateColumns = false;
            this.paperGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.paperGridView.BackgroundColor = System.Drawing.SystemColors.Window;
            this.paperGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.paperGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Title,
            this.Author,
            this.Upload_Datetime});
            this.paperGridView.DataSource = this.paperBindingSource;
            this.paperGridView.Location = new System.Drawing.Point(208, 50);
            this.paperGridView.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.paperGridView.Name = "paperGridView";
            this.paperGridView.ReadOnly = true;
            this.paperGridView.RowHeadersVisible = false;
            this.paperGridView.RowHeadersWidth = 49;
            this.paperGridView.RowTemplate.Height = 24;
            this.paperGridView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.paperGridView.Size = new System.Drawing.Size(358, 356);
            this.paperGridView.TabIndex = 2;
            this.paperGridView.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.paperGridView_CellContentClick);
            this.paperGridView.CellContentDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.paperGridView_CellContentClick);
            // 
            // Title
            // 
            this.Title.DataPropertyName = "ds_Title";
            this.Title.HeaderText = "Title";
            this.Title.MinimumWidth = 6;
            this.Title.Name = "Title";
            this.Title.ReadOnly = true;
            // 
            // Author
            // 
            this.Author.DataPropertyName = "ds_Author";
            this.Author.HeaderText = "Author";
            this.Author.MinimumWidth = 6;
            this.Author.Name = "Author";
            this.Author.ReadOnly = true;
            // 
            // Upload_Datetime
            // 
            this.Upload_Datetime.DataPropertyName = "ds_Ud";
            this.Upload_Datetime.HeaderText = "Upload Datetime";
            this.Upload_Datetime.MinimumWidth = 6;
            this.Upload_Datetime.Name = "Upload_Datetime";
            this.Upload_Datetime.ReadOnly = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(46, 53);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(29, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "Area";
            // 
            // areaBox
            // 
            this.areaBox.FormattingEnabled = true;
            this.areaBox.Location = new System.Drawing.Point(77, 50);
            this.areaBox.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.areaBox.Name = "areaBox";
            this.areaBox.Size = new System.Drawing.Size(92, 21);
            this.areaBox.TabIndex = 4;
            this.areaBox.SelectedIndexChanged += new System.EventHandler(this.areaBox_SelectedIndexChanged);
            // 
            // areaEditorUser
            // 
            this.areaEditorUser.AutoSize = true;
            this.areaEditorUser.Location = new System.Drawing.Point(46, 79);
            this.areaEditorUser.Name = "areaEditorUser";
            this.areaEditorUser.Size = new System.Drawing.Size(61, 13);
            this.areaEditorUser.TabIndex = 5;
            this.areaEditorUser.Text = "Area editor:";
            // 
            // EvaluatePaper
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(934, 500);
            this.Controls.Add(this.areaEditorUser);
            this.Controls.Add(this.areaBox);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.paperGridView);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.MaximumSize = new System.Drawing.Size(950, 539);
            this.MinimumSize = new System.Drawing.Size(950, 539);
            this.Name = "EvaluatePaper";
            this.Text = "Evaluate Paper";
            this.Load += new System.EventHandler(this.EvaluatePaper_Load);
            this.Controls.SetChildIndex(this.paperGridView, 0);
            this.Controls.SetChildIndex(this.label1, 0);
            this.Controls.SetChildIndex(this.areaBox, 0);
            this.Controls.SetChildIndex(this.areaEditorUser, 0);
            ((System.ComponentModel.ISupportInitialize)(this.paperGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.paperBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.DataGridView paperGridView;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox areaBox;
        private System.Windows.Forms.DataGridViewTextBoxColumn titulo;
        private System.Windows.Forms.DataGridViewTextBoxColumn autor;
        private System.Windows.Forms.DataGridViewTextBoxColumn fechaDeEnvio;
        private System.Windows.Forms.BindingSource paperBindingSource;
        private System.Windows.Forms.DataGridViewTextBoxColumn Title;
        private System.Windows.Forms.DataGridViewTextBoxColumn Author;
        private System.Windows.Forms.DataGridViewTextBoxColumn Upload_Datetime;
        private System.Windows.Forms.Label areaEditorUser;
    }
}