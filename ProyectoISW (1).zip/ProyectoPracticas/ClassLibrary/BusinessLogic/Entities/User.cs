﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Magazine.Entities
{
    public partial class User : Person

    {
        public User()
            {
            MainAuthoredPapers = new List<Paper>();

        }
        public User(string Id, string Name, string Surname, bool Alerted, string AreasOfInterest,
            string Email, string Login, bool MagazineSubscriber, string Password) : base(Id, Name, Surname)
        {
            this.AreasOfInterest = AreasOfInterest;
            this.Email = Email;
            this.Login = Login;
            this.Password = Password;
            this.Alerted = Alerted;
            this.MagazineSubscriber = MagazineSubscriber;

            MainAuthoredPapers = new List<Paper>();

        }

    }
}
