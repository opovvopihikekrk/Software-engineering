﻿using Magazine.Entities;
using Magazine.Persistence;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace Magazine.Services
{
    public class MagazineService : IMagazineService
    {
        private readonly IDAL dal;
        public User LoggedUser
        { get; set; }
        public Entities.Magazine m { get; set; }

        public MagazineService(IDAL dal)
        {
            this.dal = dal;
            if (ExisteDB())
                m = dal.GetAll<Entities.Magazine>().First(); 
        }
        public Boolean ExisteDB()
        {
            return dal.GetAll<Entities.Magazine>().Count() != 0;
        }
        public void RemoveAllData()
        {
            dal.RemoveAllData();
        }

        public void Commit()
        {
            dal.Commit();
        }

        public void DBInitialization()
        {
            RemoveAllData();

            User u1 = new User("1234", "Pepe", "TheBoss", false, "ninguna", "ptheboss@gmail.com", "theboss",false, "1234");
            AddUser(u1);

            m = new Magazine.Entities.Magazine("Revista Universitaria", u1);
            AddMagazine(m);

            User u2 = new User("2345", "Javier", "Garcia", false, "la mia", "jgarcia@gmail.com", "jgarcia",false, "1234");
            AddUser(u2);
            Area a1 = new Area("Area 1", u1, m);
            AddArea(a1);

            User u3 = new User("3456", "Mª Carmen", "Jimenez", false, "la mia por supuesto", "mcjimenez@gmail.com", "mcjimenez",false, "1234");
            AddUser(u3);
            Area a2 = new Area("Area 2", u3, m);
            AddArea(a2);

            // De regalo
            User u4 = new User("4567", "Juan", "Campeador", false, "la mejor", "jcampeador@gmail.com", "jcampeador", false, "1234");
            AddUser(u4);

            Paper p = new Paper("testPaper",DateTime.Now,a1,u1);
            AddPaper(p);

            Issue i = new Issue(1,m);
            i.Price = 25.0;
            i.Discount = 0.2;
            AddIssue(i);
        }

        public void checkCoauthor(string id, string name, string surname) {
            Person p = GetPersonById(id);
            if (p == null)
            {
                AddPerson(id, name, surname);

            }
            else {
                if (p.Name != name || p.Surname != surname) {
                    throw new ServiceException("Person with DNI " + id + " and different name already registered.");
                }
            }
        }
        public void AddPerson(Person person)
        {
            // Restricción: No puede haber dos personas con el mismo DNI
            if (GetPersonById(person.Id) == null)
            {
                dal.Insert<Person>(person);
                dal.Commit();
            }
            else throw new ServiceException("Person with Id " + person.Id + " already exists.");
        }
        public void AddPerson(string id, string name, string surname) { 
            Person p = new Person(id, name, surname);
            AddPerson(p);
        }

        public Person GetPersonById(string id)
        {
            return dal.GetById<Person>(id);
        }

        public void AddMagazine(Magazine.Entities.Magazine magazine)
        {
            // Restricción: No puede haber dos revistas con el mismo nombre
            if (!dal.GetWhere<Magazine.Entities.Magazine>(x => x.Name == magazine.Name).Any())
            {
                dal.Insert<Magazine.Entities.Magazine>(magazine);
                dal.Commit();
            }
            else throw new ServiceException("Magazine with name " + magazine.Name + " already exists.");
        }

        public void AddArea(Area area)
        {
            // Restricción: No puede haber dos areas con el mismo nombre
            if (!ExistsArea(area.Name))
            {
                dal.Insert<Area>(area);
                dal.Commit();
            }
            else throw new ServiceException("Area with name " + area.Name + " already exists.");
        }

        // A partid de aquí escribid vuestras implementaciones
        public void AddUser(User u)
        {
            //Restriccion: No puede haber 2 user con mismo login
            if (!dal.GetWhere<Magazine.Entities.User>(x => x.Login == u.Login).Any())
            {
                
            }
            else throw new ServiceException("User with login:  " + u.Login + " already exists.");

            //No puede haber 2 user con mismo ID
            if (!dal.GetWhere<Magazine.Entities.User>(x => x.Id == u.Id).Any())
            {
                
            }
            else throw new ServiceException("User with DNI:  " + u.Id + " already exists.");

            dal.Insert<Magazine.Entities.User>(u);
            Commit();
        }
        public void AddUser(string Dni, string Name, string Surname, bool Alerted, string AreasOfInterest,
            string Email, string Login, bool subscriber, string Password)
        {
            User us = new User(Dni, Name, Surname, Alerted, AreasOfInterest, Email, Login, subscriber, Password);
            AddUser(us);

        }
        public void Login(string login, string password) {
            User u;
            try
            {
                u = dal.GetWhere<Magazine.Entities.User>(x => x.Login == login).First();
            }
            catch (Exception e) {
                u = null;
            }
            
            if (u == null) { throw new ServiceException("User not registered."); }
            else {
                if (u.Password != password)
                {
                    throw new ServiceException("Wrong password.");
                }
                else {
                    LoggedUser = u;
                }
            }
        }

        public void AddPaper(Paper p) {
            Area a = p.BelongingArea;

            a.Papers.Add(p);
            a.EvaluationPending.Add(p);
            dal.Insert<Paper>(p);
            Commit();
        }

        public void AddPaper(User u, string title, DateTime uploadDate, string areaName, ICollection<Person> CoAuthors) {
            if(!ExistsArea(areaName)) throw new ServiceException("Specify a valid area");
            Area belongingArea = dal.GetWhere<Area>(x => Equals(x.Name, areaName)).First();

            if (LoggedUser == u && belongingArea != null)
            {
                Paper p = new Paper(title, uploadDate, belongingArea, u);
                if (CoAuthors != null && CoAuthors.Count <= 4)
                {
                    foreach (Person CoAuthor in CoAuthors)
                    {
                        p.CoAuthors.Add(CoAuthor);
                        CoAuthor.CoAuthoredPapers.Add(p);

                    }                    
                    AddPaper(p);
                }
                else if (CoAuthors.Count > 4)
                {
                    throw new ServiceException("A maximum of 4 CoAuthors may be specified.");
                }
            }
            else if (LoggedUser != u)
            {
                throw new ServiceException("Logged user is not valid.");
            }
        }

        public void AddEvaluation(Evaluation e)
        { 
            dal.Insert<Magazine.Entities.Evaluation>(e);
            Commit();
        }

        public void AddIssue(Issue i)
        {
            if (dal.Exists<Issue>(i.Id)) dal.Delete<Issue>(i);

            dal.Insert<Issue>(i);
           
            Commit();
        }

        public void AddEvaluation(Paper p, DateTime dt, string comments, Boolean accepted) {
            Area a = p.BelongingArea;
            if (IsEditorFromArea(a))
            {
                Evaluation e = new Evaluation(accepted, comments, dt);
                p.Evaluation = e;
                if (e.Accepted)
                {
                    a.PublicationPending.Add(p);
                }
                a.EvaluationPending.Remove(p);
                AddEvaluation(e);
            }
            else { throw new ServiceException("Logged user is not the Area editor"); }
        }

        public string GetPaperStatus(Paper p) {
            if (dal.GetById<Paper>(p.Id) == null) throw new ServiceException("Invalid Paper");

            if (p.Evaluation == null) return "Evaluation pending";
            if (p.Evaluation.Accepted == false) return "Rejected";
            if (p.BelongingArea.PublicationPending.Contains(p)) return "Publication pending";
            return "Published";
        }

        public IList<Paper> GetPapersFromArea(Area a, Boolean evaluationPendingOnly, Boolean publishPendingOnly) {
            if (evaluationPendingOnly)
            {
                return new List<Paper> (a.EvaluationPending);
            }
            else if (publishPendingOnly) {
                return new List <Paper> (a.PublicationPending);
            }
            else
            {
                return new List<Paper> (a.Papers);
            }
        }
        public IList<Paper> GetPublishedPapersFromArea(Area a, Issue i) {
            List<Paper> l = new List<Paper>();
            foreach (Paper p in i.PublishedPapers) {
                if (p.BelongingArea.Id == a.Id) { l.Add(p);}
            }
            return l;
        }

        public void MakeIssue(Issue issue, ICollection<Paper> selectedPapers, Area a)
        {
            ICollection<Paper> l = GetPublishedPapersFromArea(a, issue);            
            foreach (Paper p in l) {
                if (!selectedPapers.Contains(p))
                {
                    a.PublicationPending.Add(p);
                    issue.PublishedPapers.Remove(p);
                }
            }
            l = selectedPapers;
            foreach (Paper p in l)
            {
                if (a.PublicationPending.Contains(p))
                {
                    a.PublicationPending.Remove(p);
                    issue.PublishedPapers.Add(p);
                }  
            }
                Commit();
        }

        public ICollection<Paper> ListAllArticles() {
            return new List<Paper>(dal.GetAll<Paper>());
        }

        public Boolean ExistsArea(string name) {
            return (dal.GetWhere<Area>(x => x.Name == name).Any());
        }

        public IList<Area> GetAllAreas(){
            return new List<Area>(dal.GetAll<Area>());
        }

        public Area GetAreaByName(string name)
        {
            return dal.GetWhere<Area>(x => x.Name == name).First();
        }
        public Issue GetIssueByNumber(int number) { 
            if(dal.GetWhere<Issue>(x => x.Number == number).Count() == 0) { return null; }
            return dal.GetWhere<Issue>(x => x.Number == number).First();
        }

        public Boolean IsAutor() {
            IEnumerable<Paper> papers = ListAllArticles();

            foreach (Paper p in papers)
                if (p.Responsible.Id != null || p.Responsible.Id == LoggedUser.Id)
                    return true;

            return false;
        }

        public Boolean IsEditor() {
            IEnumerable<Area> areas = GetAllAreas();

            foreach (Area a in areas)
                if (a.Editor.Id != null && a.Editor.Id == LoggedUser.Id)
                    return true;

            return false;
        }
        public Boolean isPublished(Issue i) {
            if (i.PublicationDate != null) { return i.PublicationDate < DateTime.Now; }
            return false;
        }

        public Boolean IsEditorFromArea(Area a)
        {
            return LoggedUser.Id == a.Editor.Id;
        }

            public Boolean IsChiefEditor() {
            return LoggedUser.Id == m.ChiefEditor.Id;
        }

        public Issue CurrentIssue()
        {
            Issue i;
            if (dal.GetWhere<Issue>(x => x.PublicationDate == null).Count() == 0)
            {
                i = new Issue(dal.GetAll<Issue>().Last().Number + 1, m);
                AddIssue(i);
            }
            else { i = dal.GetWhere<Issue>(x => x.PublicationDate == null).First(); }
            return i;
        }
        public String GetUserLogin()
        {
            if (LoggedUser != null)
                return LoggedUser.Login;
            else return "";
        }
        public ICollection<Paper> GetPublishedPapersFromIssue(Issue i) {
            return i.PublishedPapers;
        }
        public void AddPublicationData(Issue i, DateTime date, double price, double discount) { 
            i.PublicationDate= date;   
            i.Price= price;
            i.Discount= discount;
        }
        public double GetShoppingCartPrice(ICollection<Issue> shoppingCart)
        {
            double price = 0;
            foreach(Issue item in shoppingCart)
            {
                if (LoggedUser.MagazineSubscriber)
                {
                    price += item.Price * (1 - item.Discount / 100);
                } else
                {
                    price += item.Price;
                }
            }
            return price;
        }

        public IList<Issue> GetAllPublishedIssues()
        {
            IList<Issue> issues = new List<Issue>(dal.GetWhere<Issue>(x => x.PublicationDate != null &&
                x.PublicationDate <= DateTime.Now));
            return issues;
        }
    }
}
