﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Magazine.Entities;


namespace Magazine.Services
{
    public interface IMagazineService
    {
        void RemoveAllData();
        void Commit();

        // Necesario para la inicialización de la BD
        void DBInitialization();
        Boolean ExisteDB();
        void AddPerson(Person p);
        void AddPerson(string dni, string name, string surname);
        void AddMagazine(Magazine.Entities.Magazine m);
        void AddArea(Area a);

        // A partir de aquí cread los vuestros
        User LoggedUser { get; set; }
        Entities.Magazine m { get; }
        void AddUser(string Dni, string Name, string Surname, bool Alerted, string AreasOfInterest,
            string Email, string Login, bool subscriber, string Password);
        void Login(string Login, string Password);
        void AddPaper(User u, string title, DateTime uploadDate, string belongingArea, ICollection<Person> CoAuthors);
        void AddEvaluation(Paper p, DateTime dt, string comments, Boolean accepted);
        void MakeIssue(Issue issue, ICollection<Paper> selectedPapers, Area a);
        string GetPaperStatus(Paper p);
        IList<Paper> GetPapersFromArea(Area a, Boolean evaluationPendingOnly, Boolean publishPendingOnly);
        ICollection<Paper> ListAllArticles();
        Boolean ExistsArea(string name);
        Boolean IsEditorFromArea(Area area);
        IList<Area> GetAllAreas();
        Area GetAreaByName(string name);  
        Boolean IsChiefEditor();
        Boolean IsEditor();
        Boolean IsAutor();
        Issue CurrentIssue();
        String GetUserLogin();
        void checkCoauthor(string id, string name, string surname);
        Person GetPersonById(string id);
        IList<Paper> GetPublishedPapersFromArea(Area a, Issue i);
        Issue GetIssueByNumber(int number);
        ICollection<Paper> GetPublishedPapersFromIssue(Issue i);
        void AddPublicationData(Issue i, DateTime date, double price, double discount);
        Boolean isPublished(Issue i);
        double GetShoppingCartPrice(ICollection<Issue> shoppingCart);
        IList<Issue> GetAllPublishedIssues();
    }
}
